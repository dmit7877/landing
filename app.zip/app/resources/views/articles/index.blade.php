@extends('layouts.app', ['page' => __('Article'), 'pageSlug' => 'article'])

@section('content')

@endsection